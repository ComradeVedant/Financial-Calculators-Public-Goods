// Function to calculate total amount for SIP
function calculateSIP() {
  const monthlyInvestment = document.getElementById("monthly-investment").value;
  const rateOfReturn = document.getElementById("rate-of-return").value;
  const timePeriod = document.getElementById("time-period").value;

  const rateOfReturnPerMonth = rateOfReturn / 1200; // 12 months in a year
  const totalMonths = timePeriod * 12  ;

  const totalAmount =
    monthlyInvestment *
    ((1 + rateOfReturnPerMonth) ** totalMonths - 1) /
    rateOfReturnPerMonth*(1+rateOfReturnPerMonth);

  return totalAmount.toFixed(2);
}

// Function to display the result on the page
function displayResult() {
  const totalAmount = calculateSIP();
  document.getElementById("total-amount").innerHTML =
    "Total amount after " + document.getElementById("time-period").value + " years: Rs. " + totalAmount;
}

// Add event listener to the calculate button
document.getElementById("calculate-button").addEventListener("click", function (event) {
  event.preventDefault();
  displayResult();
});

