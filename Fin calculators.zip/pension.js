function calculatePension() {
  const monthlyContribution = parseFloat(document.getElementById("monthlyContribution").value);
  const yearsUntilRetirement = parseInt(document.getElementById("yearsUntilRetirement").value);
  const annualInterestRate = parseFloat(document.getElementById("annualInterestRate").value) / 100;

  const monthsUntilRetirement = yearsUntilRetirement * 12;
  let pensionAmount = 0;

  for (let i = 1; i <= monthsUntilRetirement; i++) {
    pensionAmount += monthlyContribution;
    pensionAmount += (pensionAmount * annualInterestRate) / 12;
  }

  document.getElementById("pensionAmount").innerHTML = pensionAmount.toFixed(2);
}

// Function to display the result on the page
function displayResult() {
  const pensionAmount = calculatePension();
  document.getElementById("pensionAmount").innerHTML =
    pensionAmount;
}

// Add event listener to the calculate button
document.getElementById("calculate-button").addEventListener("click", function (event) {
  event.preventDefault();
  displayResult();
});
